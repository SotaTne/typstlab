Text styling.

The [text function]($text) is of particular interest.
