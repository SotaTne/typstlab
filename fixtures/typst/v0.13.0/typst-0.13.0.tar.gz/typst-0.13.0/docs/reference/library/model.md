Document structuring.

Here, you can find functions to structure your document and interact with that
structure. This includes section headings, figures, bibliography management,
cross-referencing and more.
