Data loading from external files.

These functions help you with loading and embedding data, for example from the
results of an experiment.
