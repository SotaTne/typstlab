Arranging elements on the page in different ways.

By combining layout functions, you can create complex and automatic layouts.
