Foundational types and functions.

Here, you'll find documentation for basic data types like [integers]($int) and
[strings]($str) as well as details about core computational functions.
